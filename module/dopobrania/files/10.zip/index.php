<?php get_header(); ?>
<div class="mainpagecontent">
<?php if(get_admin_options('showadsense') != '') 
{
?>
<div class="googleadbuttons">
<script type="text/javascript"><!--
google_ad_client = "<?php echo get_admin_options("gadsense");?>";
google_ad_slot = "<?php echo get_admin_options("gadslot");?>";
google_ad_width = 468;
google_ad_height = 15;
//-->
</script>
<script type="text/javascript"
src="http://pagead2.googlesyndication.com/pagead/show_ads.js">
</script>
</div> <!-- end of googleadbuttons -->
<?php
}
?>
<?php if(have_posts()) : ?>
<?php while(have_posts()) : the_post(); ?>
<div class="postcontent">
<div class="postheader">
<h2>
<a href="<?php the_permalink(); ?>" title="<?php the_title(); ?>"><?php the_title(); ?></a>
</h2>
</div> <!-- end of postheader -->
<div class="details1">
Posted in <?php the_category(', ') ?> on <?php the_time('F j, Y'); ?>
</div> <!-- end of details1 -->
<div class="storycontent">
<?php the_contents('Read more ...') ;?>
</div> <!-- end of storycontent -->

<div class="socialbmk">
<div class="icon1">
<a href="http://www.stumbleupon.com/submit?url=<?php the_permalink(); ?>&title=<?php the_title(); ?>" title="stumbleupon"></a>
</div>
<div class="icon2">
<a href="http://digg.com/submit?phase=2&url=<?php the_permalink(); ?>&title=<?php the_title(); ?>" title="Digg"></a>
</div>
<div class="icon3">
<a href="http://del.icio.us/post?url=<?php the_permalink(); ?>&title=<?php the_title(); ?>" title="Del.icio.us"></a>
</div>
<div class="icon4">
<a href="http://technorati.com/faves?add=<?php the_permalink(); ?>" title="Technorati"></a> 
</div>
<div class="icon5">
<a href="http://furl.net/storeIt.jsp?t=<?php the_title(); ?>&u=<?php the_permalink(); ?>" title="Furl"></a>
</div>
<div class="icon6">
<a href="http://reddit.com/submit?url=<?php the_permalink(); ?>&title=<?php the_title(); ?>" title="reddit"></a>
</div>
<div class="icon7"> <!-- blogger -->
<a href="http://blogmarks.net/my/new.php?mini=1&title=<?php the_title(); ?>&url=<?php echo get_permalink(); ?>" title="Blogmarks"></a>
</div>
<div class="icon8">
<a href="http://twitter.com/home?status=<?php echo get_permalink(); ?>" title="Twitter"></a>
</div>
<div class="icon9">
<a href="http://www.facebook.com/sharer.php?u=<?php echo get_permalink(); ?>&t=<?php the_title(); ?>" title="Facebook"></a>
</div>
<div class="icon10">
<a href="http://myweb2.search.yahoo.com/myresults/bookmarklet?t=<?php the_title(); ?>&u=<?php echo get_permalink() ?>" title="Yahoo"></a>
</div>
<div class="icon11">
<a href="http://www.google.com/bookmarks/mark?op=edit&bkmk=<?php echo get_permalink() ?>&title=<?php the_title(); ?>" title="Google"></a>
</div>
</div> <!-- end of socialbmk -->
<div class="details2">
<div class="dtleft">
<a href="<?php the_permalink() ?>"><tt>&rarr;&nbsp;</tt>Read the full story</a>
</div>
<div class="dtmid">
&nbsp;|&nbsp;
</div>
<div class="dtright">
<?php comments_popup_link('No Comments', '1 Comment', '% Comments'); ?>
</div>
</div> <!-- end of details2 -->
<div class="postcleardiv"></div>
</div> <!-- end of postcontent -->
<?php endwhile; ?>
<?php endif; ?>
<div class="pagenextback">
<?php if(function_exists('wpmshowpages')) { wpmshowpages(); } ?>
</div>
</div> <!-- end of mainpagecontent -->
<?php get_sidebars(); ?>
<?php get_footer(); ?>