<ol class="commentlist">
<?php foreach ($comments as $comment) : ?>
<li <?php echo $oddcomment; ?>id="comment-<?php comment_ID() ?>">
<cite>
<img src="<?php getwpmcomments("R", 32); ?>" alt="" />
<span class="author"><?php comment_author_link() ?></span><br /><span class="time"><?php comment_time() ?></span> on <a href="#comment-<?php comment_ID() ?>" title=""><?php comment_date('F jS, Y') ?></a> <?php edit_comment_link('edit','&nbsp;&nbsp;',''); ?>
</cite>
<div class="commenttext"><?php comment_text() ?></div>
<?php if ($comment->comment_approved == '0') : ?>
<p class="comtxt1">
Your comment is awaiting moderation.
</p>
<?php endif; ?>
</li>
<?php
/* Changes every other comment to a different class */
$oddcomment = ( empty( $oddcomment ) ) ? 'class="alt" ' : '';
?>
<?php endforeach; /* end for each comment */ ?>
</ol>

<?php if (comments_open()) : ?>

<?php /* This would be a good place for live preview... 
    <div id="live-preview">
        <h2 class="comments-header">Live Preview</h2>
        <?php live_preview(); ?>
    </div>
 */ ?>

    <div id="comments-form">
    
    <h2 id="comments-header">Leave a comment</h2>
    
    <?php if (get_option('comment_registration') && !$user_ID ) : ?>
        <p id="comments-blocked">You must be <a href="<?php echo get_option('siteurl'); ?>/wp-login.php?redirect_to=
        <?php the_permalink(); ?>">logged in</a> to post a comment.</p>
    <?php else : ?>

    <form action="<?php echo get_option('siteurl'); ?>/wp-comments-post.php" method="post" id="commentform">

    <?php if ($user_ID) : ?>
    
    <p>Logged in as <a href="<?php echo get_option('siteurl'); ?>/wp-admin/profile.php">
        <?php echo $user_identity; ?></a>. 
        <a href="<?php echo get_option('siteurl'); ?>/wp-login.php?action=logout" 
        title="Log out of this account">Logout</a>
    </p>
    
    <?php else : ?>
    
        <p><input type="text" name="author" id="author" value="<?php echo $comment_author; ?>" size="22" class="comtxtbox1" />
        <label for="author">Name<?php if ($req) _e(' (required)'); ?></label></p>
        
        <p><input type="text" name="email" id="email" value="<?php echo $comment_author_email; ?>" size="22" class="comtxtbox1" />
        <label for="email">E-mail (will not be published)<?php if ($req) _e(' (required)'); ?></label></p>
        
        <p><input type="text" name="url" id="url" value="<?php echo $comment_author_url; ?>" size="22" class="comtxtbox1" />
        <label for="url">Website</label></p>
    
    <?php endif; ?>

    <?php /* You might want to display this: 
        <p>XHTML: You can use these tags: <?php echo allowed_tags(); ?></p> */ ?>

        <p><textarea name="comment" id="comment" rows="8" cols="30" class="comtxtbox2"></textarea></p>
        
        <?php /* Buttons are easier to style than input[type=submit], 
                but you can replace: 
                <button type="submit" name="submit" id="sub">Submit</button>
                with: 
                <input type="submit" name="submit" id="sub" value="Submit" />
                if you like */ 
        ?>
        <p><button type="submit" name="submit" id="sub">Submit</button>
        <input type="hidden" name="comment_post_ID" value="<?php echo $id; ?>"></p>
    
    <?php do_action('comment_form', $post->ID); ?>

    </form>
    </div>

<?php endif; // If registration required and not logged in ?>

<?php else : // Comments are closed ?>
    <p id="comments-closed">Sorry, comments for this entry are closed at this time.</p>
<?php endif; ?>
