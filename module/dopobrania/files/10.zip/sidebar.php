<div class="sidebars-div">
<div class="sbclear"></div>
<?php if ( !function_exists('dynamic_sidebar')
        || !dynamic_sidebar("sidebar") ) : ?>
		
<?php endif; ?>
<!-- ////////////// sidebar tabs /////////////////////////////////////// -->
<div id="container">
		<ul class="menu">
			<li id="news" class="active">Posts</li>
			<li id="tutorials">Comments</li>
			<li id="links">Archives</li>
		</ul>
		<span class="clear">&nbsp;</span>
		<div class="content news">
		  <h1>Recent Posts</h1>
          <ul>
		  <?php wp_get_archives('type=postbypost&limit=5'); ?>
		  </ul>
		</div>
		<div class="content tutorials">
			<h1>Latest Comments</h1>
<?php
//global $wpdb;
$sqlqry = "SELECT DISTINCT ID, post_title, post_password, comment_ID,
comment_post_ID, comment_author, comment_date_gmt, comment_approved,
comment_type,comment_author_url,
SUBSTRING(comment_content,1,35) AS recentcoms
FROM $wpdb->comments
LEFT OUTER JOIN $wpdb->posts ON ($wpdb->comments.comment_post_ID =
$wpdb->posts.ID)
WHERE comment_approved = '1' AND comment_type = '' AND
post_password = ''
ORDER BY comment_date_gmt DESC
LIMIT 5";
$comments = $wpdb->get_results($sqlqry);
$output = $pre_HTML;
$output .= "\n<ul>";
foreach ($comments as $comment) {
$output .= "\n<li>" . "<a href=\"" . get_permalink($comment->ID) .
"#comment-" . $comment->comment_ID . "\" title=\"on " .
$comment->post_title . "\">" . strip_tags($comment->recentcoms)
."...</a></li>";
}
$output .= "\n</ul>";
$output .= $post_HTML;
echo $output;?>
		</div>
		<div class="content links">
			<h1>Archives</h1>
			<ul>
<?php wp_get_archives('type=monthly'); ?>
			</ul>
		</div>
</div> <!-- end of container -->
<!-- ////////////// end of sidebar tabs //////////////////////////////// -->