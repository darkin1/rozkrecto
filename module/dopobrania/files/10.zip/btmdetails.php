<div class="btmdetailsdiv">
<div class="btmdtheader">
</div>
<div class="btmdcontent">

<div class="btmleftdiv">
	<div class="headertxt">
	<div class="icondv">
	</div> <!-- endk of icondv -->
	<div class="titletxt">
	Recent Comments
	</div>
	</div> <!-- endk of headertxt -->
<ul>
<?php if (function_exists('mdv_recent_comments')) { mdv_recent_comments(); } ?>
</ul>
</div> <!-- endk of btmleftdiv -->

<div class="btmrightdiv">
<div class="postcat1">
	<div class="titletxtdiv">
		<div class="icondiv">
		</div>
		<div class="txtdiv">
		Top Commented Posts
		</div>
	</div>
<ul>
<?php if (function_exists('mdv_most_commented')) { mdv_most_commented(); } ?>
</ul>	
</div> <!-- end of postcat1 -->

<div class="postcat2">
	<div class="titletxtdiv">
		<div class="icondiv">
		</div>
		<div class="txtdiv">
		Recent Posts
		</div>
	</div>
<ul>
<?php wp_get_archives('title_li=&type=postbypost&limit=10'); ?>
</ul>	
</div> <!-- endk of postcat2 -->

</div> <!-- endk of btmrightdiv -->

</div>
<div class="btmdtbottom">
</div>
</div> <!-- end of btmdetailsdiv -->