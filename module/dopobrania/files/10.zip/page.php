<?php get_header(); ?>
<div class="mainpagecontent">

<?php if(get_admin_options('showadsense') != '') 
{
?>
<div class="googleadbuttons">
<script type="text/javascript"><!--
google_ad_client = "<?php echo get_admin_options("gadsense");?>";
google_ad_slot = "<?php echo get_admin_options("gadslot");?>";
google_ad_width = 468;
google_ad_height = 15;
//-->
</script>
<script type="text/javascript"
src="http://pagead2.googlesyndication.com/pagead/show_ads.js">
</script>
</div> <!-- end of googleadbuttons -->
<?php
}
?>

<?php if(have_posts()) : ?>
<?php while(have_posts()) : the_post(); ?>

<div class="postcontent">
<div class="pagepostheader">
<h2>
<a href="<?php the_permalink(); ?>" title="<?php the_title(); ?>"><?php the_title(); ?></a>
</h2>
</div> <!-- end of postheader -->
<div class="details1">

</div> <!-- end of details1 -->
<div class="storycontent">
<?php the_contents('Read more ...') ;?>
</div> <!-- end of storycontent -->

<div class="postcleardiv"></div>
</div> <!-- end of postcontent -->

<?php if(get_admin_options('showpagecomments') != '') 
{
?>
<?php comments_template(); ?>
<?php
}
?>

<?php endwhile; ?>
<?php endif; ?>
<div class="pagenextback">
<?php if(function_exists('wpmshowpages')) { wpmshowpages(); } ?>
</div>
</div> <!-- end of mainpagecontent -->
<?php get_sidebars(); ?>
<?php get_footer(); ?>